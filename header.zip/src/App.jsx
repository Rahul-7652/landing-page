import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'

function App() {
  const [count, setCount] = useState(0)

  return (
   <>
   <div className = 'text-black text-center text-2xl font-bold mt-7'>hello world</div>
   
   </>
  )
}

export default App
